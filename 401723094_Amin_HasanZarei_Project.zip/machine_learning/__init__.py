class LabelPrediction:
    def __init__(self):
        pass
